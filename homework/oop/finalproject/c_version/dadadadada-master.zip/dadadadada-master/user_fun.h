#pragma once
#include"item.h"
void find_package(user a);
void user_menu(user a);
void fetch_package(user a);
void daiqu_package(user a);
void ji_package_fun(user a);
void look_ji_package(user a);