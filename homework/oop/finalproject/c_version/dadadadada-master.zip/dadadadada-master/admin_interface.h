#pragma once
#include <stdio.h>

#include "item.h"
#include "admin.h"

void admin_choice();
void admin_worker_operation();
void admin_user_operation();
void admin_daishou_package_operation();
void admin_nuw_package_operation();
void admin_ruku_package_operation();