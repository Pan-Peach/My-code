#pragma once
void zhanshipanudan();
void inti();
void search();
void n(package_in* p);
void inti_package();
void space();
void send();
void worker_menu();